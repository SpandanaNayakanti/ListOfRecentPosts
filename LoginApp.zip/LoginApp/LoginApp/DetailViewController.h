//
//  DetailViewController.h
//  LoginApp
//
//  Created by Spandana Nayakanti on 12/17/16.
//  Copyright © 2016 Spandana. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITableView *TVForUserPosts;

@end
