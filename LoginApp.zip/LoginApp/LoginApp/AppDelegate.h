//
//  AppDelegate.h
//  LoginApp
//
//  Created by Spandana Nayakanti on 12/17/16.
//  Copyright © 2016 Spandana. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

