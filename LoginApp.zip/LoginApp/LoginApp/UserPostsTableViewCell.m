//
//  UserPostsTableViewCell.m
//  Application-Test
//
//  Created by Spandana Nayakanti on 12/18/16.
//  Copyright © 2016 Spandana. All rights reserved.
//

#import "UserPostsTableViewCell.h"

@implementation UserPostsTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
